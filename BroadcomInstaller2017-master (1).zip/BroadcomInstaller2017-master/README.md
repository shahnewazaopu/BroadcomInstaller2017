# BroadcomInstaller2017
Automated Shell Script Install WiFi  Driver ( Broadcom ) in Kali Linux 2017.1 
Made By SSTec Tutorials
#Broadcom Wifi Driver (802.11n) Broadcom 802.11n Network Adapter is a software program developed by Broadcom.  
The software is designed to connect to the Internet and adds a Windows Firewall exception in order to do so without being interfered with.

Download Broadcom Installer :   
https://github.com/mehedihshakeel/BroadcomInstaller2017.git   

usage :   
cd Desktop  git clone https://github.com/mehedihshakeel/BroadcomInstaller2017.git  
cd BroadcomInstaller2017  
chmod +x ./Broadcom.sh  
./Broadcom.sh

1) Install Wifi Driver
2) Show Commands
3) Quit
Please enter your choice: 



If you have  any questions & inquiries Ask me on Comment or Contact : 
Google + : https://plus.google.com/+SSTecTutorials 
Twitter : https://www.twitter.com/mehedi_shakeel 
Facebook Page : https://www.facebook.com/SSTec.Tutorials/ 
Facebook : https://www.facebook.com/5h4k33lDcr4k3r 
DON'T FORGET TO SUBSCRIBE!!! 
YouTube : www.youtube.com/stectutorials
Thank You!!!
